package com.example.callblocker

import android.Manifest
import android.graphics.Typeface
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogPage(a: MainActivity) : Page(a) {

    private val container: LinearLayout

    init {
        root.addView(a.outlineButton(s(R.string.log_clear)) {
            LogStore.clear(a)
            refresh()
        })
        container = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, a.dp(12), 0, 0)
        }
        root.addView(container)
    }

    override fun refresh() {
        container.removeAllViews()

        // بدون صلاحية جهات الاتصال لا يمكن إظهار الأسماء
        if (!a.hasPerm(Manifest.permission.READ_CONTACTS)) {
            val hint = a.card()
            hint.addView(a.bodyView(s(R.string.log_names_hint)))
            hint.addView(a.primaryButton(s(R.string.log_names_btn)) {
                a.requestPermission(Manifest.permission.READ_CONTACTS) { granted ->
                    if (!granted) a.toast(s(R.string.contacts_denied))
                    refresh()
                }
            })
            container.addView(hint)
        }

        val entries = LogStore.list(a)
        if (entries.isEmpty()) {
            val empty = a.card()
            empty.addView(a.bodyView(s(R.string.log_empty)))
            container.addView(empty)
            return
        }

        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH)
        for (e in entries) {
            val name = ContactNames.lookup(a, e.number)
            val box = a.card()

            box.addView(TextView(a).apply {
                text = name ?: ltr(e.number)
                textSize = 18f
                typeface = Typeface.create("serif", Typeface.BOLD)
                setTextColor(a.col(R.color.primary))
            })
            if (name != null) box.addView(a.bodyView(ltr(e.number)))
            box.addView(a.divider())
            box.addView(
                a.bodyView(
                    a.getString(R.string.log_last, fmt.format(Date(e.last))) + "\n" +
                            a.getString(R.string.log_count, e.count) + "\n" +
                            a.getString(R.string.log_reason, LogStore.label(a, e.reason))
                )
            )
            box.addView(a.outlineButton(s(R.string.log_add_white)) {
                Settings.addToList(a, Settings.WHITE, e.number)
                a.toast(s(R.string.added_white))
            })
            container.addView(box)
        }
    }
}
