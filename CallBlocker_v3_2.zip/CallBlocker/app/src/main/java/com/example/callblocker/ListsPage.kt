package com.example.callblocker

import android.provider.ContactsContract
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class ListsPage(a: MainActivity) : Page(a) {

    private val whiteCard: LinearLayout
    private val blackCard: LinearLayout
    private val whiteContainer: LinearLayout
    private val blackContainer: LinearLayout

    init {
        val white = buildSection(
            s(R.string.lists_white), s(R.string.lists_white_note), Settings.WHITE, true
        )
        val black = buildSection(
            s(R.string.lists_black), s(R.string.lists_black_note), Settings.BLACK, false
        )
        whiteCard = white.first
        whiteContainer = white.second
        blackCard = black.first
        blackContainer = black.second
        blackCard.visibility = View.GONE

        // شريط التبديل بين القائمتين
        root.addView(
            a.segmented(listOf(s(R.string.lists_white), s(R.string.lists_black)), 0) { i ->
                whiteCard.visibility = if (i == 0) View.VISIBLE else View.GONE
                blackCard.visibility = if (i == 1) View.VISIBLE else View.GONE
            }
        )
        root.addView(whiteCard)
        root.addView(blackCard)
    }

    override fun refresh() {
        renderList(whiteContainer, Settings.WHITE)
        renderList(blackContainer, Settings.BLACK)
    }

    private fun buildSection(
        heading: String, note: String, listKey: String, withContacts: Boolean
    ): Pair<LinearLayout, LinearLayout> {
        val card = a.card()
        card.addView(a.titleView(heading))
        card.addView(a.bodyView(note))

        val addRow = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, a.dp(8), 0, 0)
        }
        val input = a.editView(s(R.string.phone_hint)).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        addRow.addView(input)
        addRow.addView(a.outlineButton(s(R.string.add)) {
            if (Settings.addToList(a, listKey, input.text.toString())) {
                input.setText("")
                refresh()
            } else {
                a.toast(s(R.string.invalid_number))
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = a.dp(8) }
        })
        card.addView(addRow)

        if (withContacts) {
            card.addView(a.outlineButton(s(R.string.pick_contact)) {
                a.pickPhoneContact { number ->
                    if (Settings.addToList(a, Settings.WHITE, number)) refresh()
                }
            })
        }

        val container = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, a.dp(8), 0, 0)
        }
        card.addView(container)
        return Pair(card, container)
    }

    private fun renderList(container: LinearLayout, listKey: String) {
        container.removeAllViews()
        val numbers = Settings.getList(a, listKey)
        if (numbers.isEmpty()) {
            container.addView(a.bodyView(s(R.string.list_empty)))
            return
        }
        for ((index, n) in numbers.withIndex()) {
            if (index > 0) container.addView(a.divider())
            val name = ContactNames.lookup(a, n)

            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val texts = LinearLayout(a).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            // الاسم إن كان محفوظاً، ثم الرقم
            if (name != null) {
                texts.addView(TextView(a).apply {
                    text = name
                    textSize = 17f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(a.col(R.color.ink))
                })
                texts.addView(TextView(a).apply {
                    text = ltr(n)
                    textSize = 14f
                    setTextColor(a.col(R.color.muted))
                })
            } else {
                texts.addView(TextView(a).apply {
                    text = ltr(n)
                    textSize = 17f
                    setTextColor(a.col(R.color.ink))
                })
            }
            row.addView(texts)
            row.addView(a.dangerTextButton(s(R.string.delete)) {
                Settings.removeFromList(a, listKey, n)
                refresh()
            })
            container.addView(row)
        }
    }
}
