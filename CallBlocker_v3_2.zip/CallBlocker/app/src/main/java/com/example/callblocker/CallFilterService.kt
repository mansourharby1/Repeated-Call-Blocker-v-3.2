package com.example.callblocker

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telephony.SmsManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CallFilterService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        val allow = CallResponse.Builder().build()

        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, allow); return
        }
        val number = details.handle?.schemeSpecificPart
        if (number.isNullOrBlank()) {
            respondToCall(details, allow); return
        }
        val key = Settings.key(number)
        if (key.isEmpty()) {
            respondToCall(details, allow); return
        }

        // 1) الحظر متوقف من المفتاح السريع
        if (!Settings.isEnabled(this)) {
            respondToCall(details, allow); return
        }
        // 2) القائمة البيضاء: لا تحظر ولا تسجّل
        if (Settings.inList(this, Settings.WHITE, number)) {
            respondToCall(details, allow); return
        }
        // 3) جهات الاتصال المحفوظة
        if (Settings.isContactsExempt(this) && isSavedContact(number)) {
            respondToCall(details, allow); return
        }
        // 4) القائمة السوداء: حظر دائم بلا رسالة
        if (Settings.inList(this, Settings.BLACK, number)) {
            block(details)
            LogStore.add(this, number, LogStore.R_BLACK)
            Notifier.notifyBlocked(this, number, LogStore.R_BLACK)
            return
        }
        // 5) خارج ساعات التفعيل
        if (!Settings.isActiveNow(this)) {
            respondToCall(details, allow); return
        }

        // 6) منطق المدة وعدد المكالمات المسموحة
        val windowMs = Settings.getMinutes(this) * 60_000L
        val maxCalls = Settings.getMaxCalls(this)
        val prefs = getSharedPreferences("calls", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val start = prefs.getLong("start_$key", 0L)
        val count = prefs.getInt("cnt_$key", 0)

        if (start == 0L || now - start >= windowMs) {
            // بداية نافذة جديدة
            prefs.edit().putLong("start_$key", now).putInt("cnt_$key", 1).apply()
            respondToCall(details, allow)
        } else if (count < maxCalls) {
            prefs.edit().putInt("cnt_$key", count + 1).apply()
            respondToCall(details, allow)
        } else {
            block(details)
            sendReplyOncePerDay(number, key, prefs, now)
            LogStore.add(this, number, LogStore.R_REPEAT)
            Notifier.notifyBlocked(this, number, LogStore.R_REPEAT)
        }
    }

    private fun block(details: Call.Details) {
        respondToCall(
            details,
            CallResponse.Builder()
                .setDisallowCall(true)
                .setRejectCall(true)
                .setSkipNotification(true)
                .build()
        )
    }

    private fun isSavedContact(number: String): Boolean {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        return try {
            val uri = Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)
            )
            contentResolver.query(
                uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null
            )?.use { it.count > 0 } ?: false
        } catch (e: Exception) {
            false
        }
    }

    /** رسالة واحدة فقط في اليوم لكل رقم، وبشرط تفعيل خيار الإرسال */
    private fun sendReplyOncePerDay(number: String, key: String, prefs: SharedPreferences, now: Long) {
        if (!Settings.isSmsEnabled(this)) return
        val today = SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).format(Date(now))
        if (prefs.getString("smsday_$key", null) == today) return
        if (sendReply(number)) {
            prefs.edit().putString("smsday_$key", today).apply()
        }
    }

    private fun sendReply(number: String): Boolean {
        return try {
            val sms = if (Build.VERSION.SDK_INT >= 31)
                getSystemService(SmsManager::class.java)
            else
                @Suppress("DEPRECATION") SmsManager.getDefault()
            val parts = sms.divideMessage(Settings.replyText(this))
            sms.sendMultipartTextMessage(number, null, parts, null, null)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
