package com.example.callblocker

import android.content.Context
import java.util.Calendar
import java.util.Locale

object Settings {
    private const val PREFS = "settings"

    const val WHITE = "whitelist"
    const val BLACK = "blacklist"

    const val DEFAULT_MINUTES = 30

    /** وسوم المدة المقبولة داخل نص الرسالة (بكل اللغات) */
    private val DURATION_TAGS = listOf("{duration}", "{المدة}", "{durée}")

    private fun p(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------- اللغة والتهيئة الأولى ----------
    fun getLang(c: Context): String? = p(c).getString("lang", null)
    fun setLang(c: Context, v: String) = p(c).edit().putString("lang", v).apply()

    fun isOnboarded(c: Context) = p(c).getBoolean("onboarded", false)
    fun setOnboarded(c: Context, v: Boolean) = p(c).edit().putBoolean("onboarded", v).apply()

    // ---------- نغمة الإشعار ----------
    // القيمة: "" = الافتراضية، "silent" = صامتة، غير ذلك = رابط النغمة
    fun getSound(c: Context): String = p(c).getString("sound_uri", "") ?: ""
    fun getSoundName(c: Context): String = p(c).getString("sound_name", "") ?: ""
    fun getSoundVersion(c: Context): Int = p(c).getInt("sound_ver", 0)

    /** قناة الإشعار لا تتغير نغمتها بعد إنشائها، لذلك نرفع الرقم لإنشاء قناة جديدة */
    fun setSound(c: Context, uri: String, name: String) {
        p(c).edit()
            .putString("sound_uri", uri)
            .putString("sound_name", name)
            .putInt("sound_ver", getSoundVersion(c) + 1)
            .apply()
        Notifier.cleanup(c)
    }

    fun soundLabel(c: Context): String {
        val lc = Lang.localized(c)
        return when (val s = getSound(c)) {
            "" -> lc.getString(R.string.tone_default)
            "silent" -> lc.getString(R.string.tone_silent)
            else -> getSoundName(c).ifBlank { s.substringAfterLast('/') }
        }
    }

    // ---------- تشغيل / إيقاف سريع ----------
    fun isEnabled(c: Context) = p(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    // ---------- إرسال الرسالة للمتصل ----------
    fun isSmsEnabled(c: Context) = p(c).getBoolean("sms_enabled", true)
    fun setSmsEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("sms_enabled", v).apply()

    // ---------- المدة ----------
    fun getMinutes(c: Context): Int = p(c).getInt("minutes", DEFAULT_MINUTES)
    fun setMinutes(c: Context, v: Int) = p(c).edit().putInt("minutes", v).apply()

    // ---------- عدد المكالمات المسموحة قبل الحظر ----------
    fun getMaxCalls(c: Context): Int = p(c).getInt("max_calls", 1)
    fun setMaxCalls(c: Context, v: Int) = p(c).edit().putInt("max_calls", v).apply()

    // ---------- استثناء جهات الاتصال ----------
    fun isContactsExempt(c: Context) = p(c).getBoolean("contacts_exempt", false)
    fun setContactsExempt(c: Context, v: Boolean) =
        p(c).edit().putBoolean("contacts_exempt", v).apply()

    // ---------- الإشعارات ----------
    fun isNotifyEnabled(c: Context) = p(c).getBoolean("notify", false)
    fun setNotify(c: Context, v: Boolean) = p(c).edit().putBoolean("notify", v).apply()

    // ---------- ساعات التفعيل ----------
    fun isAllDay(c: Context) = p(c).getBoolean("all_day", true)
    fun setAllDay(c: Context, v: Boolean) = p(c).edit().putBoolean("all_day", v).apply()
    fun getStart(c: Context): Int = p(c).getInt("start_min", 8 * 60)
    fun setStart(c: Context, v: Int) = p(c).edit().putInt("start_min", v).apply()
    fun getEnd(c: Context): Int = p(c).getInt("end_min", 22 * 60)
    fun setEnd(c: Context, v: Int) = p(c).edit().putInt("end_min", v).apply()

    fun formatTime(minutes: Int): String =
        String.format(Locale.ENGLISH, "%02d:%02d", minutes / 60, minutes % 60)

    fun isActiveNow(c: Context): Boolean {
        if (isAllDay(c)) return true
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val s = getStart(c)
        val e = getEnd(c)
        return when {
            s == e -> true               // نفس الوقت = اليوم كله
            s < e -> now in s until e    // مثال 08:00 إلى 22:00
            else -> now >= s || now < e  // يمتد بعد منتصف الليل مثل 22:00 إلى 06:00
        }
    }

    // ---------- نص الرسالة ----------
    fun getCustomMessage(c: Context): String = p(c).getString("message", "") ?: ""
    fun setCustomMessage(c: Context, v: String) = p(c).edit().putString("message", v).apply()

    fun durationPhrase(c: Context, minutes: Int): String {
        val lc = Lang.localized(c)
        return when (minutes) {
            30 -> lc.getString(R.string.dur_half_hour)
            60 -> lc.getString(R.string.dur_hour)
            120 -> lc.getString(R.string.dur_two_hours)
            else -> lc.getString(R.string.dur_minutes, minutes)
        }
    }

    /** نماذج الرسائل الجاهزة بلغة التطبيق */
    fun templates(c: Context): Array<String> =
        Lang.localized(c).resources.getStringArray(R.array.templates)

    /** يستبدل وسم المدة بوقت الانتظار الحالي */
    fun fillTemplate(c: Context, template: String): String {
        val phrase = durationPhrase(c, getMinutes(c))
        var out = template
        for (tag in DURATION_TAGS) out = out.replace(tag, phrase)
        return out
    }

    /** رقم النموذج المختار (0..)، أو -1 إذا كانت الرسالة مكتوبة يدوياً */
    fun getMsgChoice(c: Context): Int {
        val pr = p(c)
        return when {
            pr.contains("msg_choice") -> pr.getInt("msg_choice", 0)
            getCustomMessage(c).isNotBlank() -> -1   // إعدادات قديمة فيها نص مخصص
            else -> 0
        }
    }
    fun setMsgChoice(c: Context, v: Int) = p(c).edit().putInt("msg_choice", v).apply()

    fun replyText(c: Context): String {
        val choice = getMsgChoice(c)
        val list = templates(c)
        val template = if (choice in list.indices) list[choice]
        else getCustomMessage(c).trim().ifEmpty { list[0] }
        return fillTemplate(c, template)
    }

    // ---------- القائمة البيضاء والسوداء ----------
    fun getList(c: Context, listKey: String): List<String> =
        (p(c).getStringSet(listKey, emptySet()) ?: emptySet()).toList().sorted()

    private fun saveList(c: Context, listKey: String, set: Set<String>) =
        p(c).edit().putStringSet(listKey, set).apply()

    /** يضيف الرقم للقائمة ويزيله من القائمة الأخرى لتجنب التعارض */
    fun addToList(c: Context, listKey: String, number: String): Boolean {
        val cleaned = clean(number)
        if (digitsOnly(cleaned).length < 3) return false
        val k = key(cleaned)

        val set = getList(c, listKey).toMutableSet()
        set.add(cleaned)
        saveList(c, listKey, set)

        val otherKey = if (listKey == WHITE) BLACK else WHITE
        val other = getList(c, otherKey).filter { key(it) != k }.toSet()
        saveList(c, otherKey, other)
        return true
    }

    fun removeFromList(c: Context, listKey: String, number: String) {
        val set = getList(c, listKey).toMutableSet()
        set.remove(number)
        saveList(c, listKey, set)
    }

    fun inList(c: Context, listKey: String, number: String): Boolean {
        val k = key(number)
        if (k.isEmpty()) return false
        return getList(c, listKey).any { key(it) == k }
    }

    // ---------- أدوات الأرقام ----------
    /** يحوّل الأرقام العربية إلى إنجليزية ويُبقي الأرقام وعلامة + فقط */
    fun clean(number: String): String {
        val sb = StringBuilder()
        for (ch in number.trim()) {
            val d = Character.digit(ch, 10)
            when {
                d >= 0 -> sb.append(d)
                ch == '+' && sb.isEmpty() -> sb.append('+')
            }
        }
        return sb.toString()
    }

    private fun digitsOnly(number: String) = clean(number).filter { it.isDigit() }

    /** مفتاح المقارنة: آخر 9 أرقام، ليتطابق 010xxxxxxxx مع +2010xxxxxxxx */
    fun key(number: String): String = digitsOnly(number).takeLast(9)
}
