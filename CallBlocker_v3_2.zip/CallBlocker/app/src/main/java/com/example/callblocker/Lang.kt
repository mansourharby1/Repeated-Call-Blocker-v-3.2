package com.example.callblocker

import android.content.Context
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import java.util.Locale

/** إدارة لغة التطبيق: ar / en / fr */
object Lang {
    const val AR = "ar"
    const val EN = "en"
    const val FR = "fr"

    fun saved(c: Context): String? = Settings.getLang(c)

    /** يحفظ اللغة المختارة (تُختار مرة واحدة فقط في أول تشغيل) */
    fun choose(c: Context, code: String) {
        Settings.setLang(c, code)
        apply(code)
    }

    private fun apply(code: String) {
        val want = LocaleListCompat.forLanguageTags(code)
        if (AppCompatDelegate.getApplicationLocales() != want) {
            AppCompatDelegate.setApplicationLocales(want)
        }
    }

    /** يُستدعى عند بدء أي عملية للتطبيق (واجهة أو خدمة) */
    fun applySaved(c: Context) {
        saved(c)?.let { apply(it) }
    }

    /** سياق بلغة التطبيق المختارة، للخدمات والإشعارات والرسائل النصية */
    fun localized(c: Context): Context {
        val code = saved(c) ?: return c
        val conf = Configuration(c.resources.configuration)
        conf.setLocale(Locale.forLanguageTag(code))
        return c.createConfigurationContext(conf)
    }
}
