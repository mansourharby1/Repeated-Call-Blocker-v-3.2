package com.example.callblocker

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.IntentCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

/**
 * النشاط الوحيد في التطبيق. يعرض بالترتيب:
 *  1) اختيار اللغة (أول مرة فقط)
 *  2) تفعيل الصلاحيات (أول مرة فقط)
 *  3) الصفحات الخمس مع شريط التنقل السفلي
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TAB = "tab"
        const val TAB_LOG = 3
        private const val STATE_TAB = "state_tab"
    }

    enum class Status { OK, SMS_MISSING, OFF }

    private var current = 0
    private var mainShown = false

    private lateinit var header: HeaderBar
    private lateinit var content: FrameLayout
    private lateinit var pages: List<Page>
    private val navItems = ArrayList<Pair<ImageView, TextView>>()

    /** زر الرجوع: من أي صفحة إلى الرئيسية، ومن الرئيسية يخرج من التطبيق */
    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            select(0)
        }
    }

    // ---------- المشغّلات (Launchers) ----------
    private var permCb: ((Boolean) -> Unit)? = null
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val cb = permCb
            permCb = null
            cb?.invoke(granted)
        }

    private val multiPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            onPermissionsResult()
        }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            onRoleResult()
        }

    private var contactCb: ((String) -> Unit)? = null
    private val contactLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            val cb = contactCb
            contactCb = null
            if (uri != null && cb != null) {
                contentResolver.query(
                    uri,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.let { cb(it) }
                }
            }
        }

    private var toneCb: ((Uri?) -> Unit)? = null
    private val toneLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = toneCb
            toneCb = null
            if (result.resultCode == RESULT_OK && cb != null) {
                val picked = result.data?.let {
                    IntentCompat.getParcelableExtra(
                        it, RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java
                    )
                }
                cb(picked) // null = صامتة
            }
        }

    private var audioCb: ((Uri) -> Unit)? = null
    private val audioLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            val cb = audioCb
            audioCb = null
            if (uri != null) cb?.invoke(uri)
        }

    // ---------- أدوات تستخدمها الصفحات ----------
    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun hasPerm(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun requestPermission(p: String, cb: (Boolean) -> Unit) {
        if (hasPerm(p)) {
            cb(true)
            return
        }
        permCb = cb
        permLauncher.launch(p)
    }

    fun ensureNotifyPermission(cb: (Boolean) -> Unit) {
        if (Build.VERSION.SDK_INT < 33) cb(true)
        else requestPermission(Manifest.permission.POST_NOTIFICATIONS, cb)
    }

    fun pickPhoneContact(cb: (String) -> Unit) {
        contactCb = cb
        contactLauncher.launch(
            Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)
        )
    }

    fun pickRingtone(title: String, existing: Uri?, cb: (Uri?) -> Unit) {
        toneCb = cb
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, title)
            if (existing != null) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
        }
        toneLauncher.launch(intent)
    }

    fun pickAudioFile(cb: (Uri) -> Unit) {
        audioCb = cb
        audioLauncher.launch("audio/*")
    }

    fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    fun versionLabel(): String = getString(R.string.version_fmt, versionName())

    // ---------- حالة التفعيل ----------
    fun roleHeld(): Boolean {
        val rm = getSystemService(RoleManager::class.java)
        return rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    }

    fun status(): Status {
        val smsOk = hasPerm(Manifest.permission.SEND_SMS)
        val smsNeeded = Settings.isSmsEnabled(this)
        return when {
            roleHeld() && (!smsNeeded || smsOk) -> Status.OK
            roleHeld() -> Status.SMS_MISSING
            else -> Status.OFF
        }
    }

    // ---------- دورة الحياة ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen() // الشعار بدل الشاشة البيضاء عند فتح التطبيق
        super.onCreate(savedInstanceState)
        onBackPressedDispatcher.addCallback(this, backCallback)

        val tabFromIntent =
            if (savedInstanceState == null) intent.getIntExtra(EXTRA_TAB, -1) else -1
        current = savedInstanceState?.getInt(STATE_TAB) ?: tabFromIntent.coerceAtLeast(0)
        route()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_TAB, current)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val tab = intent.getIntExtra(EXTRA_TAB, -1)
        if (tab >= 0 && mainShown) select(tab)
    }

    override fun onResume() {
        super.onResume()
        if (mainShown) pages[current].refresh()
    }

    /** يحدد الشاشة المناسبة: اللغة ← الصلاحيات ← الصفحات الرئيسية */
    private fun route() {
        if (Lang.saved(this) == null) {
            showLanguageStep()
            return
        }
        // مستخدمو الإصدارات السابقة الذين فعّلوا التطبيق لا يحتاجون خطوة الصلاحيات
        if (!Settings.isOnboarded(this) && roleHeld()) Settings.setOnboarded(this, true)
        if (!Settings.isOnboarded(this)) {
            showSetupStep()
            return
        }
        showMain()
    }

    // ---------- الخطوة 1: اللغة ----------
    private fun fullScreenBlue(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setBackgroundColor(col(R.color.primary))
        setPadding(dp(28), dp(48), dp(28), dp(28))
    }

    private fun whiteText(text: String, sizeSp: Float, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = sizeSp
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        if (bold) typeface = Typeface.create("serif", Typeface.BOLD)
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun showLanguageStep() {
        mainShown = false
        backCallback.isEnabled = false
        val box = fullScreenBlue()
        box.addView(logoView(120))
        box.addView(whiteText(getString(R.string.lang_title), 24f, true))
        box.addView(whiteText(getString(R.string.lang_hint), 14f, false))
        box.addView(View(this), LinearLayout.LayoutParams(MATCH, dp(16)))

        val choices = listOf("العربية" to Lang.AR, "English" to Lang.EN, "Français" to Lang.FR)
        for ((label, code) in choices) {
            box.addView(lightButton(label) {
                Lang.choose(this, code)
                route() // إن أُعيد إنشاء النشاط بسبب تغيير اللغة يُعاد تحديد الشاشة تلقائياً
            })
        }
        box.addView(whiteText(versionLabel(), 13f, false))
        setContentView(box)
    }

    // ---------- الخطوة 2: الصلاحيات (أول مرة فقط) ----------
    private fun showSetupStep() {
        mainShown = false
        backCallback.isEnabled = false
        val box = fullScreenBlue()
        box.addView(logoView(100))
        box.addView(whiteText(getString(R.string.setup_title), 24f, true))
        box.addView(whiteText(getString(R.string.setup_body), 15f, false))
        box.addView(View(this), LinearLayout.LayoutParams(MATCH, dp(16)))
        box.addView(lightButton(getString(R.string.setup_button)) { startActivation() })
        box.addView(whiteText(versionLabel(), 13f, false))
        setContentView(box)
    }

    /** يطلب الصلاحيات ثم يطلب جعل التطبيق تطبيق فرز المكالمات */
    fun startActivation() {
        val wanted = ArrayList<String>()
        wanted.add(Manifest.permission.SEND_SMS)
        wanted.add(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = wanted.filter { !hasPerm(it) }
        if (missing.isEmpty()) requestCallScreeningRole()
        else multiPermLauncher.launch(missing.toTypedArray())
    }

    private fun onPermissionsResult() {
        if (!Settings.isOnboarded(this)) {
            // ضبط الخيارات الافتراضية حسب ما مُنح في أول تشغيل
            Settings.setSmsEnabled(this, hasPerm(Manifest.permission.SEND_SMS))
            Settings.setNotify(
                this,
                Build.VERSION.SDK_INT < 33 || hasPerm(Manifest.permission.POST_NOTIFICATIONS)
            )
        }
        requestCallScreeningRole()
    }

    private fun requestCallScreeningRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
        ) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
        } else {
            onRoleResult()
        }
    }

    private fun onRoleResult() {
        if (!Settings.isOnboarded(this)) {
            Settings.setOnboarded(this, true)
            showMain()
        } else if (mainShown) {
            pages[current].refresh()
        }
    }

    // ---------- الصفحات الرئيسية ----------
    private fun showMain() {
        header = HeaderBar(this)
        pages = listOf(
            HomePage(this), RulesPage(this), ListsPage(this), LogPage(this), AlertsPage(this)
        )
        content = FrameLayout(this)

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(col(R.color.bg))
            addView(header.view, LinearLayout.LayoutParams(MATCH, WRAP))
            addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
            addView(View(this@MainActivity).apply { setBackgroundColor(col(R.color.line)) },
                LinearLayout.LayoutParams(MATCH, dp(1)))
            addView(buildNav(), LinearLayout.LayoutParams(MATCH, WRAP))
        }
        setContentView(outer)
        mainShown = true
        select(current.coerceIn(0, pages.size - 1))
    }

    private fun buildNav(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(col(R.color.card))
        }
        val rippleBg = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, rippleBg, true)

        val items = listOf(
            R.drawable.ic_nav_home to R.string.nav_home,
            R.drawable.ic_nav_rules to R.string.nav_rules,
            R.drawable.ic_nav_lists to R.string.nav_lists,
            R.drawable.ic_nav_log to R.string.nav_log,
            R.drawable.ic_nav_alerts to R.string.nav_alerts
        )
        navItems.clear()
        for ((index, item) in items.withIndex()) {
            val icon = ImageView(this).apply {
                setImageResource(item.first)
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24))
            }
            val label = TextView(this).apply {
                text = getString(item.second)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(0, dp(2), 0, 0)
            }
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(2), dp(8), dp(2), dp(8))
                setBackgroundResource(rippleBg.resourceId)
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
                setOnClickListener { select(index) }
                addView(icon)
                addView(label)
            }
            navItems.add(icon to label)
            bar.addView(cell)
        }
        return bar
    }

    fun select(index: Int) {
        current = index
        content.removeAllViews()
        content.addView(pages[index].view)

        val titles = listOf(
            R.string.app_name, R.string.title_rules, R.string.title_lists,
            R.string.title_log, R.string.title_alerts
        )
        header.set(getString(titles[index]), if (index == 0) getString(R.string.app_tagline) else null)

        for ((i, pair) in navItems.withIndex()) {
            val color = col(if (i == index) R.color.primary else R.color.muted)
            pair.first.setColorFilter(color)
            pair.second.setTextColor(color)
            pair.second.setTypeface(null, if (i == index) Typeface.BOLD else Typeface.NORMAL)
        }
        backCallback.isEnabled = index != 0
        pages[index].refresh()
    }
}
