package com.example.callblocker

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Lang.applySaved(this)
    }
}
