package com.example.callblocker

import android.Manifest
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

/** صفحة الرسائل التلقائية + الإشعارات ونغماتها */
class AlertsPage(a: MainActivity) : Page(a) {

    companion object {
        private const val CUSTOM_RADIO = 4999
        private const val TPL_BASE = 5000
    }

    private val smsSwitch: SwitchCompat
    private val messageBox: LinearLayout
    private val templatesGroup: RadioGroup
    private val customBox: LinearLayout
    private val messageInput: EditText

    private val notifySwitch: SwitchCompat
    private val currentToneView: TextView
    private val myTonesBox: LinearLayout
    private var player: Ringtone? = null

    init {
        // ====================== الرد التلقائي بالرسالة ======================
        val smsCard = a.card()
        smsCard.addView(a.titleView(s(R.string.sms_title)))

        messageBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }

        smsSwitch = a.switchView(s(R.string.sms_switch)).apply {
            isChecked = Settings.isSmsEnabled(a)
            setOnCheckedChangeListener { _, checked ->
                messageBox.visibility = if (checked) View.VISIBLE else View.GONE
                if (!checked) {
                    Settings.setSmsEnabled(a, false)
                } else {
                    a.requestPermission(Manifest.permission.SEND_SMS) { granted ->
                        Settings.setSmsEnabled(a, granted)
                        if (!granted) {
                            isChecked = false
                            a.toast(s(R.string.sms_denied))
                        }
                    }
                }
            }
        }
        smsCard.addView(smsSwitch)
        smsCard.addView(a.bodyView(s(R.string.sms_note)))

        messageBox.addView(a.subtitleView(s(R.string.sms_choose)))

        templatesGroup = RadioGroup(a).apply { orientation = RadioGroup.VERTICAL }
        for (i in Settings.templates(a).indices) {
            templatesGroup.addView(a.radioView(TPL_BASE + i, previewText(i)))
        }
        templatesGroup.addView(a.radioView(CUSTOM_RADIO, s(R.string.custom_radio)))
        messageBox.addView(templatesGroup)

        customBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        customBox.addView(a.bodyView(s(R.string.custom_hint)))
        messageInput = a.editView(s(R.string.message_hint)).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            setText(Settings.getCustomMessage(a))
        }
        customBox.addView(messageInput)
        customBox.addView(a.primaryButton(s(R.string.save_message)) { saveCustomMessage() })
        messageBox.addView(customBox)

        // الحالة الأولية
        val choice = Settings.getMsgChoice(a)
        val isTemplate = choice in Settings.templates(a).indices
        templatesGroup.check(if (isTemplate) TPL_BASE + choice else CUSTOM_RADIO)
        customBox.visibility = if (isTemplate) View.GONE else View.VISIBLE
        messageBox.visibility = if (smsSwitch.isChecked) View.VISIBLE else View.GONE

        templatesGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == CUSTOM_RADIO) {
                customBox.visibility = View.VISIBLE
                if (messageInput.text.isBlank()) {
                    val idx = Settings.getMsgChoice(a)
                    val list = Settings.templates(a)
                    messageInput.setText(list[if (idx in list.indices) idx else 0])
                }
            } else if (checkedId >= TPL_BASE) {
                Settings.setMsgChoice(a, checkedId - TPL_BASE)
                customBox.visibility = View.GONE
            }
        }
        smsCard.addView(messageBox)
        root.addView(smsCard)

        // ====================== الإشعارات والنغمات ======================
        val notifCard = a.card()
        notifCard.addView(a.titleView(s(R.string.notif_title)))

        notifySwitch = a.switchView(s(R.string.notif_switch)).apply {
            isChecked = Settings.isNotifyEnabled(a)
            setOnCheckedChangeListener { _, checked ->
                if (!checked) {
                    Settings.setNotify(a, false)
                } else {
                    a.ensureNotifyPermission { granted ->
                        Settings.setNotify(a, granted)
                        if (!granted) {
                            isChecked = false
                            a.toast(s(R.string.notif_denied))
                        }
                    }
                }
            }
        }
        notifCard.addView(notifySwitch)

        notifCard.addView(a.subtitleView(s(R.string.tone_title)))
        currentToneView = a.bodyView("")
        notifCard.addView(currentToneView)

        notifCard.addView(a.outlineButton(s(R.string.tone_choose)) { chooseSystemTone() })
        notifCard.addView(a.outlineButton(s(R.string.tone_add)) { addToneFromFile() })
        notifCard.addView(a.primaryButton(s(R.string.tone_test)) {
            a.ensureNotifyPermission { granted ->
                if (granted) Notifier.notifyTest(a) else a.toast(s(R.string.notif_denied))
            }
        })

        notifCard.addView(a.subtitleView(s(R.string.tone_mine)))
        myTonesBox = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        notifCard.addView(myTonesBox)
        root.addView(notifCard)
    }

    override fun refresh() {
        smsSwitch.isChecked = Settings.isSmsEnabled(a)
        notifySwitch.isChecked = Settings.isNotifyEnabled(a) && Notifier.canPost(a)
        refreshTemplates()
        refreshTones()
    }

    // ---------------- الرسائل ----------------
    private fun previewText(i: Int): String =
        Settings.fillTemplate(a, Settings.templates(a)[i])

    private fun refreshTemplates() {
        for (i in Settings.templates(a).indices) {
            templatesGroup.findViewById<RadioButton>(TPL_BASE + i)?.text = previewText(i)
        }
    }

    private fun saveCustomMessage() {
        val t = messageInput.text.toString().trim()
        if (t.isEmpty()) {
            a.toast(s(R.string.message_empty))
            return
        }
        Settings.setCustomMessage(a, t)
        Settings.setMsgChoice(a, -1)
        a.toast(s(R.string.message_saved))
    }

    // ---------------- النغمات ----------------
    private fun refreshTones() {
        currentToneView.text = a.getString(R.string.tone_current, Settings.soundLabel(a))

        myTonesBox.removeAllViews()
        val tones = Tones.list(a)
        if (tones.isEmpty()) {
            myTonesBox.addView(a.bodyView(s(R.string.tone_none)))
            return
        }
        val selected = Settings.getSound(a)
        for ((index, tone) in tones.withIndex()) {
            if (index > 0) myTonesBox.addView(a.divider())
            val isSelected = tone.uri == selected
            val row = LinearLayout(a).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(a).apply {
                text = (if (isSelected) "●  " else "○  ") + tone.name
                textSize = 16f
                setTextColor(a.col(if (isSelected) R.color.primary else R.color.ink))
                setPadding(0, a.dp(10), 0, a.dp(10))
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
                setOnClickListener {
                    Settings.setSound(a, tone.uri, tone.name)
                    playPreview(Uri.parse(tone.uri))
                    refreshTones()
                }
            })
            row.addView(a.dangerTextButton(s(R.string.delete)) {
                Tones.remove(a, tone)
                refreshTones()
            })
            myTonesBox.addView(row)
        }
    }

    private fun playPreview(uri: Uri) {
        try {
            player?.stop()
            player = RingtoneManager.getRingtone(a, uri)?.also { it.play() }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** اختيار نغمة من نغمات النظام (تتضمن الافتراضية والصامتة والنغمات المضافة) */
    private fun chooseSystemTone() {
        val current = Settings.getSound(a)
        val existing: Uri? = when (current) {
            "" -> android.provider.Settings.System.DEFAULT_NOTIFICATION_URI
            "silent" -> null
            else -> Uri.parse(current)
        }
        a.pickRingtone(s(R.string.tone_picker_title), existing) { picked ->
            when {
                picked == null -> Settings.setSound(a, "silent", "")
                picked == android.provider.Settings.System.DEFAULT_NOTIFICATION_URI ->
                    Settings.setSound(a, "", "")
                else -> {
                    val name = try {
                        RingtoneManager.getRingtone(a, picked)?.getTitle(a) ?: ""
                    } catch (e: Exception) {
                        ""
                    }
                    Settings.setSound(a, picked.toString(), name)
                }
            }
            refreshTones()
        }
    }

    /** إضافة نغمة جديدة من ملفات الجهاز */
    private fun addToneFromFile() {
        a.pickAudioFile { uri ->
            val handler = Handler(Looper.getMainLooper())
            Thread {
                val tone = Tones.add(a, uri)
                handler.post {
                    if (tone == null) {
                        a.toast(s(R.string.tone_add_failed))
                    } else {
                        Settings.setSound(a, tone.uri, tone.name)
                        a.toast(s(R.string.tone_added))
                        playPreview(Uri.parse(tone.uri))
                        refreshTones()
                    }
                }
            }.start()
        }
    }
}
