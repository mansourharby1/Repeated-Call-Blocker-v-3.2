package com.example.callblocker

import android.graphics.Typeface
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

class HomePage(a: MainActivity) : Page(a) {

    private val statusView = TextView(a)
    private val enabledSwitch: SwitchCompat
    private val summaryView: TextView

    init {
        val main = a.card()
        statusView.apply {
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(a.dp(14), a.dp(10), a.dp(14), a.dp(10))
            // الضغط يعمل فقط عندما يكون التفعيل ناقصاً
            setOnClickListener { if (a.status() != MainActivity.Status.OK) a.startActivation() }
        }
        main.addView(statusView)

        enabledSwitch = a.switchView(s(R.string.switch_enabled)).apply {
            isChecked = Settings.isEnabled(a)
            setOnCheckedChangeListener { _, checked -> Settings.setEnabled(a, checked) }
        }
        main.addView(enabledSwitch)
        root.addView(main)

        val sum = a.card()
        sum.addView(a.titleView(s(R.string.summary_title)))
        summaryView = a.bodyView("")
        sum.addView(summaryView)
        root.addView(sum)

        // تغيير اللغة من الإعدادات
        val langCard = a.card()
        langCard.addView(a.titleView(s(R.string.lang_card_title)))
        val codes = listOf(Lang.AR, Lang.EN, Lang.FR)
        val currentIdx = codes.indexOf(Lang.saved(a)).coerceAtLeast(0)
        langCard.addView(a.segmented(listOf("العربية", "English", "Français"), currentIdx) { i ->
            if (i != currentIdx) Lang.choose(a, codes[i])
        })
        root.addView(langCard)

        // رقم الإصدار
        root.addView(TextView(a).apply {
            text = a.versionLabel()
            textSize = 13f
            gravity = android.view.Gravity.CENTER
            setTextColor(a.col(R.color.muted))
            setPadding(0, a.dp(4), 0, a.dp(4))
        })
    }

    override fun refresh() {
        enabledSwitch.isChecked = Settings.isEnabled(a)

        val st = a.status()
        val (textRes, fg, bg) = when (st) {
            MainActivity.Status.OK ->
                Triple(R.string.status_on, R.color.success, R.color.success_bg)
            MainActivity.Status.SMS_MISSING ->
                Triple(R.string.status_sms_missing, R.color.warn, R.color.warn_bg)
            MainActivity.Status.OFF ->
                Triple(R.string.status_off, R.color.danger, R.color.danger_bg)
        }
        statusView.text = s(textRes) +
                if (st == MainActivity.Status.OK) "" else s(R.string.status_tap_fix)
        statusView.setTextColor(a.col(fg))
        statusView.background = a.rounded(a.col(bg), 10)

        val hours = if (Settings.isAllDay(a)) s(R.string.hours_all_day)
        else a.getString(
            R.string.hours_range,
            Settings.formatTime(Settings.getStart(a)),
            Settings.formatTime(Settings.getEnd(a))
        )
        val smsLabel = s(if (Settings.isSmsEnabled(a)) R.string.on_label else R.string.off_label)
        val blocked = LogStore.list(a).sumOf { it.count }

        summaryView.text = listOf(
            a.getString(R.string.sum_blocked, blocked),
            a.getString(R.string.sum_duration, Settings.durationPhrase(a, Settings.getMinutes(a))),
            a.getString(R.string.sum_maxcalls, Settings.getMaxCalls(a)),
            a.getString(R.string.sum_hours, hours),
            a.getString(R.string.sum_sms, smsLabel)
        ).joinToString("\n")
    }
}
