package com.example.callblocker

import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView

/** صفحة من صفحات التطبيق (تُعرض داخل MainActivity مع شريط التنقل السفلي) */
abstract class Page(protected val a: MainActivity) {
    protected val root = LinearLayout(a).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(a.dp(16), a.dp(16), a.dp(16), a.dp(24))
    }
    val view: View = ScrollView(a).apply {
        isFillViewport = true
        addView(root)
    }

    /** يُستدعى عند فتح الصفحة وعند العودة للتطبيق */
    abstract fun refresh()

    protected fun s(id: Int): String = a.getString(id)
}
