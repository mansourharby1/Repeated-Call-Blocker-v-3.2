package com.example.callblocker

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

internal const val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
internal const val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.col(id: Int): Int = getColor(id)

/** يمنع انعكاس ترتيب رقم الهاتف داخل نص عربي (RTL) */
fun ltr(s: String): String = "\u200E$s\u200E"

fun Context.rounded(fill: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

private fun Context.pressable(fill: Int, stroke: Int?, radiusDp: Int): RippleDrawable {
    val content = rounded(fill, radiusDp, stroke)
    val mask = rounded(Color.WHITE, radiusDp)
    val rippleColor = (col(R.color.accent) and 0x00FFFFFF) or 0x44000000
    return RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask)
}

// ---------- النصوص ----------
fun Context.titleView(text: String) = TextView(this).apply {
    this.text = text
    textSize = 18f
    typeface = Typeface.create("serif", Typeface.BOLD)
    setTextColor(col(R.color.primary))
    setPadding(0, dp(2), 0, dp(10))
}

fun Context.subtitleView(text: String) = TextView(this).apply {
    this.text = text
    textSize = 15f
    setTypeface(typeface, Typeface.BOLD)
    setTextColor(col(R.color.primary))
    setPadding(0, dp(14), 0, dp(6))
}

fun Context.bodyView(text: String) = TextView(this).apply {
    this.text = text
    textSize = 14f
    setTextColor(col(R.color.muted))
    setLineSpacing(0f, 1.15f)
    setPadding(0, dp(4), 0, dp(4))
}

// ---------- البطاقات والفواصل ----------
fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = rounded(col(R.color.card), 16, col(R.color.line))
    setPadding(dp(16), dp(14), dp(16), dp(16))
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
}

fun Context.divider(): View = View(this).apply {
    setBackgroundColor(col(R.color.line))
    layoutParams = LinearLayout.LayoutParams(MATCH, dp(1)).apply {
        topMargin = dp(6)
        bottomMargin = dp(6)
    }
}

// ---------- الأزرار ----------
fun Context.primaryButton(label: String, onClick: () -> Unit) = Button(this).apply {
    text = label
    isAllCaps = false
    textSize = 15f
    setTypeface(typeface, Typeface.BOLD)
    setTextColor(Color.WHITE)
    background = pressable(col(R.color.primary), null, 12)
    stateListAnimator = null
    minHeight = dp(48)
    minimumHeight = dp(48)
    minWidth = dp(64)
    minimumWidth = dp(64)
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    setOnClickListener { onClick() }
}

fun Context.outlineButton(label: String, onClick: () -> Unit) = Button(this).apply {
    text = label
    isAllCaps = false
    textSize = 15f
    setTextColor(col(R.color.primary))
    background = pressable(Color.TRANSPARENT, col(R.color.accent), 12)
    stateListAnimator = null
    minHeight = dp(46)
    minimumHeight = dp(46)
    minWidth = dp(64)
    minimumWidth = dp(64)
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
    setOnClickListener { onClick() }
}

/** زر أبيض يُستخدم فوق الخلفية الزرقاء (شاشات الإعداد الأول) */
fun Context.lightButton(label: String, onClick: () -> Unit) = Button(this).apply {
    text = label
    isAllCaps = false
    textSize = 17f
    setTypeface(typeface, Typeface.BOLD)
    setTextColor(col(R.color.primary))
    background = pressable(Color.WHITE, null, 14)
    stateListAnimator = null
    minHeight = dp(54)
    minimumHeight = dp(54)
    layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
    setOnClickListener { onClick() }
}

fun Context.dangerTextButton(label: String, onClick: () -> Unit) = Button(this).apply {
    text = label
    isAllCaps = false
    textSize = 14f
    setTextColor(col(R.color.danger))
    background = pressable(Color.TRANSPARENT, null, 8)
    stateListAnimator = null
    minHeight = dp(40)
    minimumHeight = dp(40)
    minWidth = dp(56)
    minimumWidth = dp(56)
    setOnClickListener { onClick() }
}

// ---------- الحقول والمفاتيح ----------
fun Context.editView(hintText: String? = null) = EditText(this).apply {
    hint = hintText
    textSize = 16f
    setTextColor(col(R.color.ink))
    setHintTextColor(col(R.color.muted))
    background = rounded(col(R.color.bg), 10, col(R.color.line))
    setPadding(dp(12), dp(10), dp(12), dp(10))
}

fun Context.switchView(label: String) = SwitchCompat(this).apply {
    text = label
    textSize = 16f
    setTextColor(col(R.color.ink))
    setPadding(0, dp(8), 0, dp(8))
}

fun Context.radioView(viewId: Int, label: String) = RadioButton(this).apply {
    id = viewId
    text = label
    textSize = 14.5f
    setTextColor(col(R.color.ink))
    setLineSpacing(0f, 1.1f)
    setPadding(dp(8), dp(10), dp(8), dp(10))
}

/** شريط اختيار بين خيارات (مثل: القائمة البيضاء | القائمة السوداء) */
fun Context.segmented(labels: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
    val box = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        background = rounded(col(R.color.card), 14, col(R.color.line))
        setPadding(dp(3), dp(3), dp(3), dp(3))
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
    }
    val items = ArrayList<TextView>()
    fun paint(sel: Int) {
        for ((i, t) in items.withIndex()) {
            if (i == sel) {
                t.background = rounded(col(R.color.primary), 11)
                t.setTextColor(Color.WHITE)
            } else {
                t.background = null
                t.setTextColor(col(R.color.primary))
            }
        }
    }
    for ((i, label) in labels.withIndex()) {
        val t = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(10), 0, dp(10))
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            setOnClickListener {
                paint(i)
                onSelect(i)
            }
        }
        items.add(t)
        box.addView(t)
    }
    paint(selected)
    return box
}

/** شعار التطبيق (دائرة حمراء + سماعة + خط المنع) */
fun Context.logoView(sizeDp: Int) = ImageView(this).apply {
    setImageResource(R.drawable.ic_splash)
    layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
}

// ---------- الترويسة العلوية ----------
class HeaderBar(ctx: Context) {
    private val titleTv = TextView(ctx).apply {
        textSize = 22f
        typeface = Typeface.create("serif", Typeface.BOLD)
        setTextColor(Color.WHITE)
    }
    private val subTv = TextView(ctx).apply {
        textSize = 13f
        setTextColor(ctx.col(R.color.primary_soft))
        setPadding(0, ctx.dp(4), 0, 0)
    }
    val view: LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(ctx.col(R.color.primary))
        setPadding(ctx.dp(20), ctx.dp(16), ctx.dp(20), ctx.dp(16))
        addView(titleTv)
        addView(subTv)
        addView(View(ctx).apply {
            setBackgroundColor(Color.WHITE)
            alpha = 0.6f
            layoutParams = LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(2)).apply {
                topMargin = ctx.dp(10)
            }
        })
    }

    fun set(title: String, subtitle: String?) {
        titleTv.text = title
        subTv.text = subtitle ?: ""
        subTv.visibility = if (subtitle == null) View.GONE else View.VISIBLE
    }
}
