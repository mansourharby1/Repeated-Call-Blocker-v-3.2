package com.example.callblocker

import android.Manifest
import android.app.TimePickerDialog
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.widget.SwitchCompat

class RulesPage(a: MainActivity) : Page(a) {

    private val hoursBox: LinearLayout
    private val startBtn: Button
    private val endBtn: Button
    private val contactsSwitch: SwitchCompat

    init {
        // ----- مدة الحظر وعدد المكالمات -----
        val card = a.card()
        addNumberSetting(card, s(R.string.rule_minutes), Settings.getMinutes(a), 1, 1440) {
            Settings.setMinutes(a, it)
        }
        addNumberSetting(card, s(R.string.rule_maxcalls), Settings.getMaxCalls(a), 1, 20) {
            Settings.setMaxCalls(a, it)
        }
        root.addView(card)

        // ----- ساعات التفعيل -----
        val hoursCard = a.card()
        hoursCard.addView(a.titleView(s(R.string.hours_title)))
        val allDay = Settings.isAllDay(a)
        val allDaySwitch = a.switchView(s(R.string.all_day)).apply { isChecked = allDay }
        hoursCard.addView(allDaySwitch)

        hoursBox = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            visibility = if (allDay) View.GONE else View.VISIBLE
        }
        startBtn = a.outlineButton("") { pickTime(true) }.apply {
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = a.dp(4) }
        }
        endBtn = a.outlineButton("") { pickTime(false) }.apply {
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = a.dp(4) }
        }
        hoursBox.addView(startBtn)
        hoursBox.addView(endBtn)
        hoursCard.addView(hoursBox)
        updateHoursButtons()

        allDaySwitch.setOnCheckedChangeListener { _, checked ->
            Settings.setAllDay(a, checked)
            hoursBox.visibility = if (checked) View.GONE else View.VISIBLE
        }
        hoursCard.addView(a.bodyView(s(R.string.hours_note)))
        root.addView(hoursCard)

        // ----- استثناء جهات الاتصال -----
        val optCard = a.card()
        contactsSwitch = a.switchView(s(R.string.contacts_exempt)).apply {
            isChecked = Settings.isContactsExempt(a) && a.hasPerm(Manifest.permission.READ_CONTACTS)
            setOnCheckedChangeListener { _, checked ->
                if (!checked) {
                    Settings.setContactsExempt(a, false)
                } else {
                    a.requestPermission(Manifest.permission.READ_CONTACTS) { granted ->
                        Settings.setContactsExempt(a, granted)
                        if (!granted) {
                            isChecked = false
                            a.toast(s(R.string.contacts_denied))
                        }
                    }
                }
            }
        }
        optCard.addView(contactsSwitch)
        root.addView(optCard)
    }

    override fun refresh() {
        updateHoursButtons()
    }

    private fun parseInt(s: String): Int? =
        s.mapNotNull { ch -> Character.digit(ch, 10).takeIf { it >= 0 } }
            .joinToString("").toIntOrNull()

    private fun addNumberSetting(
        parent: LinearLayout, label: String, initial: Int, min: Int, max: Int,
        onSave: (Int) -> Unit
    ) {
        parent.addView(a.subtitleView(label))
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val input = a.editView().apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(initial.toString())
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        row.addView(input)
        row.addView(a.outlineButton(s(R.string.save)) {
            val v = parseInt(input.text.toString())
            if (v == null || v < min || v > max) {
                a.toast(a.getString(R.string.range_err, min, max))
            } else {
                onSave(v)
                input.setText(v.toString())
                a.toast(s(R.string.saved))
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = a.dp(8) }
        })
        parent.addView(row)
    }

    private fun updateHoursButtons() {
        startBtn.text = a.getString(R.string.from_fmt, Settings.formatTime(Settings.getStart(a)))
        endBtn.text = a.getString(R.string.to_fmt, Settings.formatTime(Settings.getEnd(a)))
    }

    private fun pickTime(isStart: Boolean) {
        val cur = if (isStart) Settings.getStart(a) else Settings.getEnd(a)
        TimePickerDialog(a, { _, h, m ->
            val v = h * 60 + m
            if (isStart) Settings.setStart(a, v) else Settings.setEnd(a, v)
            updateHoursButtons()
        }, cur / 60, cur % 60, true).show()
    }
}
