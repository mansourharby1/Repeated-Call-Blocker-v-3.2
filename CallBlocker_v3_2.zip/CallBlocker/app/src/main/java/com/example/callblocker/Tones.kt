package com.example.callblocker

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

/**
 * النغمات التي يضيفها المستخدم من ملفاته.
 * يُنسخ الملف إلى مجلد Notifications في وسائط الجهاز، فيستطيع النظام تشغيله
 * كنغمة إشعار، وتظهر النغمة أيضاً في قائمة نغمات النظام.
 */
object Tones {
    data class Tone(val name: String, val uri: String)

    private const val PREFS = "tones"
    private const val KEY = "list"

    @Synchronized
    fun list(c: Context): List<Tone> {
        val s = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val arr = JSONArray(s)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Tone(o.optString("n"), o.optString("u"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(c: Context, items: List<Tone>) {
        val arr = JSONArray()
        for (t in items) arr.put(JSONObject().put("n", t.name).put("u", t.uri))
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    private fun displayName(c: Context, uri: Uri): String? = try {
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    /** ينسخ الملف المختار إلى وسائط الجهاز كنغمة إشعار. يرجع null عند الفشل. */
    @Synchronized
    fun add(c: Context, src: Uri): Tone? {
        val cr = c.contentResolver
        val fileName = displayName(c, src) ?: "tone_${System.currentTimeMillis()}.mp3"
        val title = fileName.substringBeforeLast('.')
        val mime = cr.getType(src)?.takeIf { it.startsWith("audio/") } ?: "audio/mpeg"

        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Audio.Media.TITLE, title)
            put(MediaStore.Audio.Media.MIME_TYPE, mime)
            put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_NOTIFICATIONS)
            put(MediaStore.Audio.Media.IS_NOTIFICATION, 1)
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val dest: Uri = cr.insert(collection, values) ?: return null
        return try {
            val input = cr.openInputStream(src) ?: throw IllegalStateException("no input")
            val output = cr.openOutputStream(dest) ?: throw IllegalStateException("no output")
            input.use { i -> output.use { o -> i.copyTo(o) } }

            val done = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            cr.update(dest, done, null, null)

            val tone = Tone(title, dest.toString())
            save(c, list(c) + tone)
            tone
        } catch (e: Exception) {
            e.printStackTrace()
            try {
                cr.delete(dest, null, null)
            } catch (_: Exception) {
            }
            null
        }
    }

    @Synchronized
    fun remove(c: Context, tone: Tone) {
        save(c, list(c).filter { it.uri != tone.uri })
        try {
            c.contentResolver.delete(Uri.parse(tone.uri), null, null)
        } catch (e: Exception) {
            // قد لا يسمح النظام بحذف الملف؛ يكفي إزالتها من القائمة
        }
        if (Settings.getSound(c) == tone.uri) Settings.setSound(c, "", "")
    }
}
