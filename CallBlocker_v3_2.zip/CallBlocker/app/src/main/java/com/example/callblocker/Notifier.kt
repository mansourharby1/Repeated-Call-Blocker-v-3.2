package com.example.callblocker

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build

object Notifier {
    private const val PREFIX = "blocked"
    private const val TEST_ID = 9999

    private fun channelId(c: Context) = "${PREFIX}_v${Settings.getSoundVersion(c)}"

    /** يحذف القنوات القديمة (بنغمات سابقة) ويُبقي الحالية فقط */
    fun cleanup(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        val keep = channelId(c)
        for (ch in nm.notificationChannels) {
            if (ch.id.startsWith(PREFIX) && ch.id != keep) nm.deleteNotificationChannel(ch.id)
        }
    }

    private fun ensureChannel(c: Context, nm: NotificationManager): String {
        val id = channelId(c)
        if (nm.getNotificationChannel(id) == null) {
            val lc = Lang.localized(c)
            val ch = NotificationChannel(
                id, lc.getString(R.string.notif_channel), NotificationManager.IMPORTANCE_DEFAULT
            )
            when (val s = Settings.getSound(c)) {
                "" -> Unit // نغمة الإشعارات الافتراضية للنظام
                "silent" -> ch.setSound(null, null)
                else -> ch.setSound(
                    Uri.parse(s),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
            nm.createNotificationChannel(ch)
        }
        return id
    }

    fun canPost(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
                c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED

    /** شعار التطبيق الملوّن كأيقونة كبيرة داخل الإشعار */
    private fun logoBitmap(c: Context): Bitmap? = try {
        val d = c.getDrawable(R.drawable.ic_splash)!!
        val size = (64 * c.resources.displayMetrics.density).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, size, size)
        d.draw(Canvas(bmp))
        bmp
    } catch (e: Exception) {
        null
    }

    private fun post(c: Context, notifId: Int, text: String) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val lc = Lang.localized(c)
            val channel = ensureChannel(c, nm)

            // يفتح التطبيق على صفحة السجل؛ زر الرجوع منها يعيد إلى الصفحة الرئيسية
            val intent = Intent(c, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_LOG)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(
                c, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(c, channel)
                .setSmallIcon(R.drawable.ic_stat_block)
                .setColor(c.getColor(R.color.logo_red))
                .setLargeIcon(logoBitmap(c))
                .setContentTitle(lc.getString(R.string.notif_blocked))
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(notifId, n)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun notifyBlocked(c: Context, number: String, reason: String) {
        if (!Settings.isNotifyEnabled(c) || !canPost(c)) return
        val who = ContactNames.lookup(c, number) ?: ltr(number)
        post(c, Settings.key(number).hashCode(), "$who - ${LogStore.label(c, reason)}")
    }

    /** إشعار تجريبي لسماع النغمة المختارة */
    fun notifyTest(c: Context) {
        if (!canPost(c)) return
        post(c, TEST_ID, Lang.localized(c).getString(R.string.notif_test_text))
    }
}
