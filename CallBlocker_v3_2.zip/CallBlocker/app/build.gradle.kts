plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.callblocker"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.callblocker"
        minSdk = 29
        targetSdk = 34
        versionCode = 7
        versionName = "3.2"
    }

    // مفتاح توقيع ثابت: يسمح بتثبيت كل إصدار جديد فوق القديم بدون حذفه.
    // (بدونه يُنشئ كل بناء على GitHub مفتاحاً مختلفاً فيرفض الهاتف التحديث)
    signingConfigs {
        create("main") {
            storeFile = file("callblocker.jks")
            storePassword = "callblocker123"
            keyAlias = "callblocker"
            keyPassword = "callblocker123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("main")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("main")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
}
